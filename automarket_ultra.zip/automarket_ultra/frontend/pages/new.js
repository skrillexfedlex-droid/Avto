
import { useState } from 'react';
const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';
export default function NewListing(){
  const [imgUrl, setImgUrl] = useState('');
  const [msg, setMsg] = useState('');
  const [form, setForm] = useState({ title:'', brand:'', model:'', price:'', year:'', mileage:'', city:'', lat:'', lng:'' });
  const onChange = e => setForm({ ...form, [e.target.name]: e.target.value });
  const upload = async e => {
    const file = e.target.files?.[0];
    if(!file) return;
    const fd = new FormData(); fd.append('image', file);
    const r = await fetch(`${API}/api/upload`, { method:'POST', headers:{ Authorization: `Bearer ${localStorage.getItem('token')||''}` }, body: fd });
    const d = await r.json(); if(r.ok) setImgUrl(d.url);
  };
  const submit = async e => {
    e.preventDefault();
    const payload = { ...form, price: +form.price, year: +form.year, mileage: +form.mileage, lat: form.lat?+form.lat:undefined, lng: form.lng?+form.lng:undefined, images: imgUrl?[imgUrl]:[] };
    const r = await fetch(`${API}/api/listings`, { method:'POST', headers:{'Content-Type':'application/json', Authorization: `Bearer ${localStorage.getItem('token')||''}`}, body: JSON.stringify(payload)});
    setMsg(r.ok ? 'Отправлено на модерацию' : 'Ошибка');
  };
  return <div style={{padding:20, maxWidth:600}}>
    <h1>Новое объявление</h1>
    <form onSubmit={submit} style={{display:'grid', gap:8}}>
      <input name="title" placeholder="Заголовок" onChange={onChange}/>
      <input name="brand" placeholder="Бренд" onChange={onChange}/>
      <input name="model" placeholder="Модель" onChange={onChange}/>
      <input name="price" placeholder="Цена" onChange={onChange}/>
      <input name="year" placeholder="Год" onChange={onChange}/>
      <input name="mileage" placeholder="Пробег" onChange={onChange}/>
      <input name="city" placeholder="Город" onChange={onChange}/>
      <input name="lat" placeholder="Широта (опц.)" onChange={onChange}/>
      <input name="lng" placeholder="Долгота (опц.)" onChange={onChange}/>
      <input type="file" onChange={upload}/>
      {imgUrl && <img src={imgUrl} alt="preview" style={{width:200}}/>}
      <button>Отправить</button>
      <div>{msg}</div>
    </form>
  </div>
}
