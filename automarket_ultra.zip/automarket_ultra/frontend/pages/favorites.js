
import { useEffect, useState } from 'react';
const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';
export default function Favorites(){
  const [items, setItems] = useState([]);
  useEffect(()=>{
    const token = localStorage.getItem('token')||'';
    fetch(`${API}/api/favorites`, { headers:{ Authorization: `Bearer ${token}` }})
      .then(r=>r.json()).then(setItems);
  },[]);
  return <div style={{padding:20}}>
    <h1>Избранное</h1>
    <div style={{ display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:12 }}>
      {items.map(c => (
        <div key={c.id} style={{ border:'1px solid #ddd', padding:12, borderRadius:8 }}>
          {c.images?.[0] && <img src={c.images[0]} style={{width:'100%', height:150, objectFit:'cover', borderRadius:6}}/>}
          <h3>{c.title}</h3>
          <div>{c.brand} {c.model}</div>
          <div><b>{c.price}</b> ₽ • {c.year} • {c.mileage} км</div>
        </div>
      ))}
    </div>
  </div>
}
