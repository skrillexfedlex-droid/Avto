
import { useEffect, useState } from 'react';
const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';
export default function Admin(){
  const [items, setItems] = useState([]);
  const token = (typeof window !== 'undefined' && localStorage.getItem('token')) || '';
  const load = async () => {
    const r = await fetch(`${API}/api/listings/pending`, { headers:{ Authorization: `Bearer ${token}` }});
    if(r.ok) setItems(await r.json()); else alert('Нужны права модератора');
  };
  useEffect(()=>{ load(); },[]);
  const approve = async (id) => {
    const r = await fetch(`${API}/api/listings/${id}/approve`, { method:'POST', headers:{ Authorization: `Bearer ${token}` }});
    if(r.ok) load(); else alert('Ошибка');
  };
  return <div style={{padding:20}}>
    <h1>Модерация</h1>
    <div style={{ display:'grid', gridTemplateColumns:'repeat(2, 1fr)', gap:12 }}>
      {items.map(c => (
        <div key={c.id} style={{ border:'1px solid #ddd', padding:12, borderRadius:8 }}>
          <h3>{c.title}</h3>
          <div>{c.brand} {c.model} — {c.price} ₽</div>
          <div>{c.city} • год {c.year} • {c.mileage} км</div>
          <button onClick={()=>approve(c.id)}>Одобрить</button>
        </div>
      ))}
    </div>
  </div>
}
