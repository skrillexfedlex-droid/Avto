
import { useState } from 'react';
const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';
export default function Register(){
  const [form, setForm] = useState({ name:'', email:'', password:'' });
  const [msg, setMsg] = useState('');
  const onChange = e => setForm({ ...form, [e.target.name]: e.target.value });
  const submit = async e => {
    e.preventDefault();
    const r = await fetch(`${API}/api/register`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(form)});
    const d = await r.json(); setMsg(r.ok ? 'OK, войдите' : d.error || 'Ошибка');
  };
  return <div style={{padding:20}}>
    <h1>Регистрация</h1>
    <form onSubmit={submit} style={{display:'grid', gap:8, maxWidth:320}}>
      <input name="name" placeholder="Имя" onChange={onChange}/>
      <input name="email" placeholder="Email" onChange={onChange}/>
      <input type="password" name="password" placeholder="Пароль" onChange={onChange}/>
      <button>Создать аккаунт</button>
      <div>{msg}</div>
    </form>
  </div>
}
