
import { useEffect, useState } from 'react';
const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';

export default function Roles(){
  const [users, setUsers] = useState([]);
  const token = (typeof window !== 'undefined' && localStorage.getItem('token')) || '';

  const load = async () => {
    const r = await fetch(`${API}/api/admin/users`, { headers:{ Authorization: `Bearer ${token}` }});
    if(r.ok) setUsers(await r.json()); else alert('Нужны права ADMIN');
  };
  useEffect(()=>{ load(); },[]);

  const changeRole = async (id, role) => {
    const r = await fetch(`${API}/api/admin/users/${id}/role`, {
      method:'POST',
      headers:{ 'Content-Type':'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ role })
    });
    if(r.ok) load(); else alert('Ошибка смены роли');
  };

  return <div style={{padding:20}}>
    <h1>Управление ролями</h1>
    <table border="1" cellPadding="8">
      <thead><tr><th>ID</th><th>Имя</th><th>Email</th><th>Роль</th><th>Действия</th></tr></thead>
      <tbody>
        {users.map(u => (
          <tr key={u.id}>
            <td>{u.id}</td><td>{u.name}</td><td>{u.email}</td><td>{u.role}</td>
            <td>
              <button onClick={()=>changeRole(u.id,'USER')}>USER</button>{' '}
              <button onClick={()=>changeRole(u.id,'MODERATOR')}>MODERATOR</button>{' '}
              <button onClick={()=>changeRole(u.id,'ADMIN')}>ADMIN</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
}
