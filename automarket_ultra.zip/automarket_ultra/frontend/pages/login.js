
import { useState } from 'react';
const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';
export default function Login(){
  const [form, setForm] = useState({ email:'', password:'' });
  const [msg, setMsg] = useState('');
  const onChange = e => setForm({ ...form, [e.target.name]: e.target.value });
  const submit = async e => {
    e.preventDefault();
    const r = await fetch(`${API}/api/login`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(form)});
    const d = await r.json();
    if(r.ok){ localStorage.setItem('token', d.token); setMsg('OK'); } else setMsg(d.error||'Ошибка');
  };
  return <div style={{padding:20}}>
    <h1>Вход</h1>
    <form onSubmit={submit} style={{display:'grid', gap:8, maxWidth:320}}>
      <input name="email" placeholder="Email" onChange={onChange}/>
      <input type="password" name="password" placeholder="Пароль" onChange={onChange}/>
      <button>Войти</button>
      <div>{msg}</div>
    </form>
  </div>
}
