import { useEffect, useState } from 'react';
const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';

export default function Home() {
  const [cars, setCars] = useState([]);
  const [featured, setFeatured] = useState([]);
  const [brand, setBrand] = useState('');
  const [city, setCity] = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');

  useEffect(() => {
    fetch(`${API}/api/listings`).then(res => res.json()).then(setCars);
    fetch(`${API}/api/listings?onlyFeatured=1`).then(r=>r.json()).then(setFeatured);
  }, []);

  const search = async (e) => {
    e.preventDefault();
    const qs = new URLSearchParams({ brand, city, minPrice, maxPrice });
    const res = await fetch(`${API}/api/listings?${qs.toString()}`);
    setCars(await res.json());
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>AutoMarket Ultra</h1>
      <nav style={{marginTop:8, marginBottom:12}}>
        <a href="/new">Новое объявление</a> · <a href="/login">Вход</a> · <a href="/register">Регистрация</a> · <a href="/favorites">Избранное</a> · <a href="/map">Карта</a> · <a href="/compare">Сравнить цены</a> · <a href="/admin">Модерация</a> · <a href="/pricing">Тарифы</a> · <a href="/roles">Роли</a>
      </nav>

      <h2>Премиум объявления</h2>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:12, marginBottom:16 }}>
        {featured.map(c => (
          <div key={c.id} style={{ border:'2px solid gold', padding:12, borderRadius:8 }}>
            {c.images?.[0] && <img src={c.images[0]} style={{width:'100%', height:150, objectFit:'cover', borderRadius:6}}/>}
            <h3>⭐ {c.title}</h3>
            <div>{c.brand} {c.model}</div>
            <div><b>{c.price}</b> ₽ • {c.year} • {c.mileage} км</div>
            <div>{c.city}</div>
          </div>
        ))}
      </div>

      <h2>Каталог</h2>
      <form onSubmit={search} style={{ display: 'grid', gap: 8, gridTemplateColumns: 'repeat(5, 1fr)', marginTop: 12 }}>
        <input placeholder="Бренд" value={brand} onChange={e=>setBrand(e.target.value)} />
        <input placeholder="Город" value={city} onChange={e=>setCity(e.target.value)} />
        <input placeholder="Цена от" value={minPrice} onChange={e=>setMinPrice(e.target.value)} />
        <input placeholder="Цена до" value={maxPrice} onChange={e=>setMaxPrice(e.target.value)} />
        <button type="submit">Искать</button>
      </form>

      <div style={{ display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:12, marginTop:16 }}>
        {cars.map(c => (
          <div key={c.id} style={{ border:'1px solid #ddd', padding:12, borderRadius:8 }}>
            {c.images?.[0] && <img src={c.images[0]} style={{width:'100%', height:150, objectFit:'cover', borderRadius:6}}/>}
            <h3>{c.title}</h3>
            <div>{c.brand} {c.model}</div>
            <div><b>{c.price}</b> ₽ • {c.year} • {c.mileage} км</div>
            <div>{c.city}</div>
            <button onClick={async ()=>{
              const token = localStorage.getItem('token')||'';
              const r = await fetch(`${API}/api/favorites/${c.id}`,{ method:'POST', headers:{ Authorization: `Bearer ${token}` }});
              alert(r.ok ? 'Добавлено в избранное' : 'Нужно войти');
            }}>В избранное</button>
          </div>
        ))}
      </div>
    </div>
  );
}
