
import { useState } from 'react';
const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';
export default function Compare(){
  const [brand, setBrand] = useState('');
  const [model, setModel] = useState('');
  const [city, setCity] = useState('');
  const [stats, setStats] = useState(null);
  const run = async e => {
    e.preventDefault();
    const qs = new URLSearchParams({ brand, model, city });
    const r = await fetch(`${API}/api/compare?${qs}`);
    setStats(await r.json());
  };
  return <div style={{padding:20}}>
    <h1>Сравнение цен</h1>
    <form onSubmit={run} style={{display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8, maxWidth:720}}>
      <input placeholder="Бренд" value={brand} onChange={e=>setBrand(e.target.value)}/>
      <input placeholder="Модель" value={model} onChange={e=>setModel(e.target.value)}/>
      <input placeholder="Город (опц.)" value={city} onChange={e=>setCity(e.target.value)}/>
      <button>Сравнить</button>
    </form>
    {stats && <div style={{marginTop:16}}>
      <div>Объявлений: {stats.count}</div>
      <div>Средняя цена: {stats.avg} ₽</div>
      <div>Мин: {stats.min} ₽ • Макс: {stats.max} ₽</div>
    </div>}
  </div>
}
