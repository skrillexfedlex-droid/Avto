
import dynamic from 'next/dynamic';
import { useEffect, useState } from 'react';
const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';
const Map = dynamic(() => import('../shared/Map'), { ssr: false });
export default function MapPage(){
  const [cars, setCars] = useState([]);
  useEffect(() => { fetch(`${API}/api/listings`).then(r=>r.json()).then(setCars); }, []);
  return <div style={{ height:'100vh' }}><Map items={cars}/></div>;
}
