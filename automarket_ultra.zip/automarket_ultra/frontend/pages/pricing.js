
const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';
export default function Pricing(){
  let listingIdInput;
  const buy = async () => {
    const listingId = Number(listingIdInput.value);
    if(!listingId) return alert('Укажи ID объявления');
    const token = localStorage.getItem('token')||'';
    const r = await fetch(`${API}/api/pay/checkout`, {
      method:'POST',
      headers:{ 'Content-Type':'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ listingId })
    });
    const d = await r.json();
    if (d.url) window.location = d.url; else alert(d.error || 'Ошибка');
  };
  return <div style={{padding:20}}>
    <h1>Тарифы</h1>
    <p>Премиум — пометка ⭐ и поднятие в каталоге. Оплата через Stripe Checkout.</p>
    <input placeholder="ID объявления" ref={r=>listingIdInput=r} />
    <button onClick={buy}>Купить премиум</button>
    <p>Нужно включить Stripe webhook: см. README.</p>
  </div>
}
