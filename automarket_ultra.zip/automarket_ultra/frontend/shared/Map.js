import { useEffect } from 'react';
import L from 'leaflet';

export default function Map({ items=[] }){
  useEffect(() => {
    const map = L.map('map').setView([38.5598, 68.7870], 6);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map);

    let group;
    if (window.L && window.L.markerClusterGroup) {
      group = window.L.markerClusterGroup();
      items.filter(i=>i.lat && i.lng).forEach(i => {
        const m = L.marker([i.lat, i.lng]).bindPopup(`${i.title} — ${i.price}₽`);
        group.addLayer(m);
      });
      map.addLayer(group);
    } else {
      items.filter(i=>i.lat && i.lng).forEach(i => L.marker([i.lat, i.lng]).addTo(map).bindPopup(`${i.title} — ${i.price}₽`));
    }
    return () => map.remove();
  }, [items]);
  return <div id="map" style={{ width:'100%', height:'100%' }} />;
}
