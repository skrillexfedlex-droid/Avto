import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { PrismaClient } from '@prisma/client';
import { z } from 'zod';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import Stripe from 'stripe';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import crypto from 'crypto';
import getRawBody from 'raw-body';

dotenv.config();
const app = express();
const prisma = new PrismaClient();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret';
const CORS_ORIGIN = process.env.CORS_ORIGIN || '*';
const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;

app.use(cors({ origin: CORS_ORIGIN.split(',') }));
app.use(express.json({ verify: (req, res, buf) => {
  // Keep raw body for webhook route
  if (req.originalUrl.startsWith('/api/pay/webhook')) req.rawBody = buf;
}}));

// Upload setup
const uploadDir = path.join(process.cwd(), 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });
app.use('/uploads', express.static(uploadDir));
const upload = multer({ dest: uploadDir });

// S3 client
const s3Enabled = String(process.env.S3_ENABLED||'false') === 'true';
let s3 = null;
if (s3Enabled) {
  s3 = new S3Client({
    region: process.env.S3_REGION || 'us-east-1',
    endpoint: process.env.S3_ENDPOINT,
    forcePathStyle: String(process.env.S3_FORCE_PATH_STYLE||'false') === 'true',
    credentials: {
      accessKeyId: process.env.S3_ACCESS_KEY,
      secretAccessKey: process.env.S3_SECRET_KEY
    }
  });
}
const S3_BUCKET = process.env.S3_BUCKET;

// ---- Utils ----
const auth = async (req, res, next) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'No token' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid token' });
  }
};
const roleAny = roles => (req,res,next) => {
  if (!req.user?.role || !roles.includes(req.user.role)) return res.status(403).json({ error: 'Forbidden' });
  next();
};

// ---- Auth ----
app.post('/api/register', async (req, res) => {
  try {
    const schema = z.object({ name:z.string().min(2), email:z.string().email(), password:z.string().min(6) });
    const data = schema.parse(req.body);
    const hash = await bcrypt.hash(data.password, 10);
    const user = await prisma.user.create({ data: { name: data.name, email: data.email, password: hash } });
    res.json({ id: user.id, email: user.email, name: user.name });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.password);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ sub: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
});

// ---- File Upload ----
app.post('/api/upload', auth, upload.single('image'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file' });
  try {
    if (s3) {
      const key = `${req.user.sub}/${Date.now()}-${crypto.randomBytes(6).toString('hex')}`;
      const fileBuf = fs.readFileSync(req.file.path);
      await s3.send(new PutObjectCommand({
        Bucket: S3_BUCKET,
        Key: key,
        Body: fileBuf,
        ContentType: 'image/jpeg'
      }));
      const url = `${process.env.S3_ENDPOINT}/${S3_BUCKET}/${key}`;
      fs.unlinkSync(req.file.path);
      return res.json({ url });
    } else {
      const urlPath = `/uploads/${req.file.filename}`;
      return res.json({ url: urlPath });
    }
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
});

// ---- Listings ----
app.post('/api/listings', auth, async (req, res) => {
  try {
    const schema = z.object({
      title: z.string().min(3),
      brand: z.string(),
      model: z.string(),
      price: z.number().int().nonnegative(),
      year: z.number().int().min(1900).max(new Date().getFullYear()),
      mileage: z.number().int().nonnegative(),
      city: z.string(),
      lat: z.number().optional(),
      lng: z.number().optional(),
      images: z.array(z.string()).optional().default([]),
    });
    const data = schema.parse(req.body);
    const listing = await prisma.listing.create({ data: { ...data, userId: req.user.sub, approved: false } });
    res.json(listing);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.get('/api/listings', async (req, res) => {
  const { brand, minPrice, maxPrice, city, onlyFeatured } = req.query;
  const where = { approved: true };
  if (brand) where.brand = String(brand);
  if (city) where.city = String(city);
  if (onlyFeatured) where.featured = true;
  if (minPrice || maxPrice) where.price = { gte: minPrice ? Number(minPrice) : undefined, lte: maxPrice ? Number(maxPrice) : undefined };
  const listings = await prisma.listing.findMany({ where, orderBy: [{ featured: 'desc' }, { createdAt: 'desc' }] });
  res.json(listings);
});

app.get('/api/listings/pending', auth, roleAny(['MODERATOR','ADMIN']), async (req, res) => {
  const items = await prisma.listing.findMany({ where: { approved: false }, orderBy: { createdAt: 'desc' } });
  res.json(items);
});

app.post('/api/listings/:id/approve', auth, roleAny(['MODERATOR','ADMIN']), async (req, res) => {
  const id = Number(req.params.id);
  const listing = await prisma.listing.update({ where: { id }, data: { approved: true } });
  res.json(listing);
});

app.post('/api/listings/:id/feature', auth, roleAny(['ADMIN']), async (req, res) => {
  const id = Number(req.params.id);
  const listing = await prisma.listing.update({ where: { id }, data: { featured: true } });
  res.json(listing);
});

app.get('/api/listings/:id', async (req, res) => {
  const id = Number(req.params.id);
  const listing = await prisma.listing.findUnique({ where: { id } });
  if (!listing || !listing.approved) return res.status(404).json({ error: 'Not found' });
  res.json(listing);
});

// ---- Favorites ----
app.post('/api/favorites/:id', auth, async (req, res) => {
  const listingId = Number(req.params.id);
  await prisma.favorite.upsert({
    where: { userId_listingId: { userId: req.user.sub, listingId } },
    update: {},
    create: { userId: req.user.sub, listingId }
  });
  res.json({ ok: true });
});
app.delete('/api/favorites/:id', auth, async (req, res) => {
  const listingId = Number(req.params.id);
  await prisma.favorite.delete({ where: { userId_listingId: { userId: req.user.sub, listingId } } }).catch(()=>{});
  res.json({ ok: true });
});
app.get('/api/favorites', auth, async (req, res) => {
  const favs = await prisma.favorite.findMany({ where: { userId: req.user.sub }, include: { listing: true } });
  res.json(favs.map(f => f.listing));
});

// ---- Compare ----
app.get('/api/compare', async (req, res) => {
  const { brand, model, city } = req.query;
  if (!brand || !model) return res.status(400).json({ error: 'brand and model required' });
  const where = { brand: String(brand), model: String(model), approved: true };
  if (city) where.city = String(city);
  const data = await prisma.listing.findMany({ where, select: { price: true } });
  if (!data.length) return res.json({ count: 0, avg: 0, min: 0, max: 0 });
  const prices = data.map(x => x.price);
  const sum = prices.reduce((a,b)=>a+b,0);
  res.json({ count: prices.length, avg: Math.round(sum/prices.length), min: Math.min(...prices), max: Math.max(...prices) });
});

// ---- Stripe Checkout ----
app.post('/api/pay/checkout', auth, async (req, res) => {
  if (!stripe) return res.status(400).json({ error: 'Stripe not configured' });
  const { listingId } = req.body;
  if (!listingId) return res.status(400).json({ error: 'listingId required' });
  const listing = await prisma.listing.findUnique({ where: { id: listingId } });
  if (!listing) return res.status(404).json({ error: 'Listing not found' });

  const session = await stripe.checkout.sessions.create({
    mode: 'payment',
    line_items: [{
      price_data: {
        currency: 'usd',
        product_data: { name: `Премиум размещение: ${listing.title}` },
        unit_amount: 500 * 100
      },
      quantity: 1
    }],
    metadata: { listingId: String(listingId), userId: String(req.user.sub) },
    success_url: process.env.STRIPE_SUCCESS_URL,
    cancel_url: process.env.STRIPE_CANCEL_URL
  });
  res.json({ url: session.url });
});

// ---- Stripe Webhook ----
app.post('/api/pay/webhook', async (req, res) => {
  if (!stripe) return res.status(400).send('Stripe not configured');
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    const buf = req.rawBody || await getRawBody(req);
    event = stripe.webhooks.constructEvent(buf, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature verification failed.', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const listingId = Number(session.metadata?.listingId);
    if (listingId) {
      await prisma.listing.update({ where: { id: listingId }, data: { featured: true, approved: true } }).catch(()=>{});
    }
  }
  res.json({ received: true });
});

// ---- Admin: roles ----
app.get('/api/admin/users', auth, roleAny(['ADMIN']), async (req, res) => {
  const users = await prisma.user.findMany({ orderBy: { id: 'asc' } });
  res.json(users.map(u => ({ id: u.id, name: u.name, email: u.email, role: u.role })));
});
app.post('/api/admin/users/:id/role', auth, roleAny(['ADMIN']), async (req, res) => {
  const id = Number(req.params.id);
  const { role } = req.body;
  if (!['USER','MODERATOR','ADMIN'].includes(role)) return res.status(400).json({ error: 'Bad role' });
  const user = await prisma.user.update({ where: { id }, data: { role } });
  res.json({ id: user.id, role: user.role });
});

app.get('/health', (_req, res) => res.json({ ok: true }));

app.listen(PORT, () => console.log(`API on :${PORT}`));
