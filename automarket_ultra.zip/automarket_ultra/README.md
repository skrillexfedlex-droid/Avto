# AutoMarket Ultra — с вебхуками Stripe и управлением ролями

Дополнено:
- Вебхук Stripe `/api/pay/webhook` — после успешной оплаты автоматически ставит `featured=true` у объявления.
- Админ API для ролей: список пользователей, смена роли; UI страница `/roles`.
- Остальной функционал: S3/MinIO для фото, модерация, кластеризация карты, сравнение цен.

## Запуск
```bash
docker compose up --build
```
MinIO: http://localhost:9001 (minioadmin/minioadmin) — создай бакет `automarket` и сделай публичное чтение.

## Stripe Webhook
1) Установи Stripe CLI и выполни:
```bash
stripe listen --forward-to localhost:5000/api/pay/webhook
```
2) Скопируй секрет, подставь в `STRIPE_WEBHOOK_SECRET` (docker-compose или backend/.env), перезапусти backend.

После успешной оплаты Checkout (событие `checkout.session.completed`) — объявление станет премиум.

## Роли
Страница `/roles` доступна ADMIN. Можно повышать до MODERATOR/ADMIN.

